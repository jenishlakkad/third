import logo from './logo.svg';
import './App.css';
import DashboardComponent from './component/DashboardComponent';

function App() {
  return (
    <div className="App">
     <DashboardComponent/>
    </div>
  );
}

export default App;
